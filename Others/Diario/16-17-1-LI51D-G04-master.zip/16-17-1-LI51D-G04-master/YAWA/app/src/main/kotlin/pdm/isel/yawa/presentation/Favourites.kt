package pdm.isel.yawa.presentation

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.widget.LinearLayoutManager
import android.text.InputType
import android.util.Log
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_favourites.*
import pdm.isel.yawa.R
import pdm.isel.yawa.comms.FavouritesViewAdapter
import pdm.isel.yawa.model.entities.Place
import java.util.*
import android.content.Context
import pdm.isel.yawa.R.id.recyclerView
import android.support.v7.widget.RecyclerView




class Favourites : AppCompatActivity() {
    private var mLinearLayoutManager: LinearLayoutManager? = null
    private var mAdapter: FavouritesViewAdapter? = null
    lateinit var places: ArrayList<Place>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favourites)

        supportActionBar?.title = resources.getString(R.string.title_favorites)

        mLinearLayoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = mLinearLayoutManager

        places = ArrayList()
        if (containsCities()) {

            //Load from sharedPreferences
            val prefs = this.getSharedPreferences("YAWA", Context.MODE_PRIVATE)
            val favCity = prefs.getString("FavouriteCity", null)

            if (favCity != null) {
                places.add(Place(true, favCity))
            }

        }

        mAdapter = FavouritesViewAdapter(places)
        recyclerView.adapter = mAdapter

        recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView?, dx: Int, dy: Int) {
                if (dy > 0)
                    fab.hide()
                else if (dy < 0)
                    fab.show()
            }
        })

        fab.setOnClickListener {

            val builder = AlertDialog.Builder(this)
            builder.setTitle("Add a city")

            // Set up the input
            val input = EditText(this)
            // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
            input.inputType = InputType.TYPE_CLASS_TEXT
            builder.setView(input)

            // Set up the buttons
            builder.setPositiveButton("OK") { dialog, which ->

                if (!presentInList(input.text.toString())) {
                    mAdapter!!.addPlace(Place(false, input.text.toString()))
                    mAdapter!!.notifyItemInserted(places.size - 1)
                    places = mAdapter!!.getListPlaces()
                }

            }
            builder.setNegativeButton("Cancel") { dialog, which -> dialog.cancel() }

            builder.show()
        }
    }


    override fun onBackPressed() {
        super.onBackPressed()
        val settings = getSharedPreferences("YAWA", Context.MODE_PRIVATE)
        val prefEditor = settings.edit()

        prefEditor.remove("FavouriteCity")
        prefEditor.remove("Cities")

        if (getFavouriteCity() != "") {
            prefEditor.putString("FavouriteCity", getFavouriteCity())
        }

        if (setCities() != null) {
            prefEditor.putStringSet("Cities", setCities())
        }

        prefEditor.commit()
    }

    private fun containsCities(): Boolean {
        val prefs = this.getSharedPreferences("YAWA", Context.MODE_PRIVATE)
        val favCity = prefs.getString("FavouriteCity", null)
        val othersCity = prefs.getStringSet("Cities", null)

        return favCity != null || othersCity != null
    }

    private fun setCities(): Set<String>? {
        val set = HashSet<String>()

        if (mAdapter!!.places.size == 0)
            return null

        for (item: Place in mAdapter!!.places) {
            if (!item.isFavourite) {
                set.add(item.name)
            }
        }

        return set;
    }

    public fun getFavouriteCity(): String {
        return mAdapter!!.places
                .firstOrNull { it.isFavourite }
                ?.name
                ?: ""
    }

    private fun presentInList(name: String): Boolean {
        return places.any { it.name == name }
    }
}
