package pdm.isel.yawa.model.entities

import android.os.Parcel
import android.os.Parcelable

data class WeatherForecastVO(
        val name : String,
        val list: List<WeatherVO>
): Parcelable {

    companion object {
        /** Factory of Forecast instances */
        @JvmField @Suppress("unused")
        val CREATOR = object : Parcelable.Creator<WeatherForecastVO> {
            override fun createFromParcel(source: Parcel) = WeatherForecastVO(source)
            override fun newArray(size: Int): Array<WeatherForecastVO?> = arrayOfNulls(size)
        }
    }

    /**
     * Initiates an instance from the given parcel.
     * @param source The parcel from where the data is to be loaded from
     */
    constructor(source: Parcel) : this(
            name = source.readString(),
            list = mutableListOf<WeatherVO>().apply {  source.readTypedList(this, WeatherVO.CREATOR) }
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.apply {
            writeString(name)
            writeTypedList(list)
        }
    }

    override fun describeContents() = 0

}