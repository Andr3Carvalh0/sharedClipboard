package pdm.isel.yawa

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.android.volley.RequestQueue
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_main.*
import pdm.isel.yawa.comms.GetWeatherForecastRequest
import pdm.isel.yawa.comms.GetWeatherRequest
import pdm.isel.yawa.model.entities.WeatherForecastDto
import pdm.isel.yawa.model.entities.WeatherForecastVO
import pdm.isel.yawa.model.entities.WeatherVO
import pdm.isel.yawa.presentation.*
import java.util.*
import java.util.concurrent.CountDownLatch

class MainActivity : AppCompatActivity() {

    /**
     * This class is responsible for getting the info of a current Weather.
     */
    private inner class AsyncCurrentWeather(private val savedInstanceState: Bundle?) : AsyncTask<String, Void, WeatherVO>() {

        /**
         * Returns a Movie containing the details of a movie.
         * @param params
         * *
         * @return
         */
        protected override fun doInBackground(vararg params: String): WeatherVO {
            return (application as YAWA).databridge!!.dailyInfo(params[0])
        }

        /**
         * Crates a fragment if it doesn't exist, to hold the movie poster.
         * @param movie
         */
        override fun onPostExecute(weather: WeatherVO) {
           startDailyActivity(weather)
        }
    }

    /**
     * AsyncTask responsible for getting the movies to populate the ListView.
     */
    private inner class AsyncForecast(private val savedInstanceState: Bundle?) : AsyncTask<String, Void, WeatherForecastVO>() {

        /**
         * Returns a MovieList containing all the movies to populate the ListView.
         * @param params
         * *
         * @return
         */
        override fun doInBackground(vararg params: String): WeatherForecastVO {
            return (application as YAWA).databridge!!.forecastInfo(params[0])
        }

        /**
         * Sets the adapter for the ListView, and sets the listener for each item
         * of the list.
         * @param movies
         */
        override fun onPostExecute(forecast: WeatherForecastVO) {
            startForecastActivity(forecast)
        }
    }

    private lateinit var weatherForecast: ArrayList<String?>
    private lateinit var city: String
    private lateinit var prefs: SharedPreferences

    /**
     * @property requestQueue The request queue to be used for request dispatching
     */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sendBroadcast(Intent(".controller.broadcastReceivers.YAWABroadcastUpdater"))
        sendBroadcast(Intent(".controller.broadcastReceivers.YAWABroadcast"))

        prefs = this.getSharedPreferences("YAWA", Context.MODE_PRIVATE)

        main_daily.setOnClickListener {
            city = main_city_value.text.toString()
            if(city.equals(""))
                city = prefs.getString("FavouriteCity", "Lisbon")
            val progressDaily = ProgressDialog.show(this, resources.getString(R.string.main_loading_title_label), resources.getString(R.string.main_loading_label), true)
            progressDaily.dismiss()
            if ((application as YAWA).connectionHandler!!.isConnected){ fetchWeatherInfo((application as YAWA).requestQueue)}
            else AsyncCurrentWeather(savedInstanceState).execute(city)
        }

        main_forecast.setOnClickListener {
            city = main_city_value.text.toString()
            if(city.equals(""))
                city = prefs.getString("FavouriteCity", "Lisbon")
            weatherForecast = ArrayList()
            val progressForecast = ProgressDialog.show(this, resources.getString(R.string.main_loading_title_label),
                    resources.getString(R.string.main_loading_label), true);
            progressForecast.dismiss()
            if ((application as YAWA).connectionHandler!!.isConnected) fetchWeatherForecastInfo((application as YAWA).requestQueue)
            else AsyncForecast(savedInstanceState).execute(city)
        }


    }

    fun startDailyActivity(weather: WeatherVO){
        val it = Intent(this, DailyActivity::class.java)
        it.putExtra("weather", weather)
        startActivity(it)
    }

    fun startForecastActivity(forecast: WeatherForecastVO){
        val it = Intent(this, ForecastActivity::class.java)
        it.putExtra("forecast", forecast)
        startActivity(it)
    }

    fun createForecastVO(forecast: WeatherForecastDto): WeatherForecastVO{
        val list = ArrayList<WeatherVO>()
        for(weather in forecast.list){
            list.add(WeatherVO(weather.name.orEmpty(), weather.main.temp.toInt(),
                    weather.main.temp_min.toInt(), weather.main.temp_max.toInt(),
                    weather.weather[0].main, weather.clouds.all, weather.weather[0].icon, weather.time))
        }
        return WeatherForecastVO(forecast.city.name, list)
    }

    /**
     * Helper method used to fetch the current weather information.
     */
    private fun fetchWeatherInfo(requestQueue : RequestQueue) {
        requestQueue.add(
                GetWeatherRequest(
                        resources.getString(R.string.weather_daily_main) + city + resources.getString(R.string.weather_daily_end),
                        { weatherDto ->
                            val weatherVO = WeatherVO(weatherDto.name.orEmpty(), weatherDto.main.temp.toInt(),
                                    weatherDto.main.temp_min.toInt(), weatherDto.main.temp_max.toInt(),
                                    weatherDto.weather[0].main, weatherDto.clouds.all, weatherDto.weather[0].icon, weatherDto.time)
                            startDailyActivity(weatherVO)
                        },
                        { error ->
                            Toast.makeText(this, resources.getString(R.string.main_error_label), Toast.LENGTH_SHORT).show() }

                )
        )
    }

    /**
     * Helper method used to fetch the current weather information.
     */
    private fun fetchWeatherForecastInfo(requestQueue : RequestQueue) {
        requestQueue.add(
                GetWeatherForecastRequest(
                        resources.getString(R.string.weather_forecast_main) + city + resources.getString(R.string.weather_forecast_end),
                        { weatherForecastDto ->
                            startForecastActivity(createForecastVO(weatherForecastDto))
                        },
                        { error ->

                            Toast.makeText(this, resources.getString(R.string.main_error_label), Toast.LENGTH_SHORT).show() }

                )
        )
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_home, menu)
        return true
    }



    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item?.itemId

        //noinspection SimplifiableIfStatement

        if(id == R.id.action_about){
            startActivity(Intent(this, CreditsActivity::class.java))
            return true;
        }
        if(id == R.id.action_settings){
            startActivity(Intent(this, SettingsActivity::class.java))
            return true;
        }

        return super.onOptionsItemSelected(item)
    }
}
