package pdm.isel.yawa.model.data.database

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * This class is an SQLiteOpenHelper which creates the database,
 * and deletes it when the database is upgraded.
 */
class WeatherDBHelper(context: Context) : SQLiteOpenHelper(context, WeatherDBHelper.DATABASE_NAME, null, WeatherDBHelper.DATABASE_VERSION) {

    /**
     * Creates the database.
     * @param db
     */
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(DatabaseUtils.SQL_CREATE_CURRENT_WEATHER)
        db.execSQL(DatabaseUtils.SQL_CREATE_FORECAST_WEATHER)
    }

    /**
     * Deletes the current database, and creates a new one.
     * @param db
     * *
     * @param oldVersion
     * *
     * @param newVersion
     */
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL(DatabaseUtils.SQL_DELETE_CURRENT_WEATHER)
        db.execSQL(DatabaseUtils.SQL_DELETE_FORECAST_WEATHER)
        onCreate(db)
    }

    companion object {

        private val DATABASE_NAME = "Weather.db"
        private val DATABASE_VERSION = 1
    }
}

