package pdm.isel.yawa.model.entities


class Place(favourite: Boolean, name: String){

    var  name: String
    var  isFavourite: Boolean

    init{
        this.name = name
        this.isFavourite = favourite
    }


    override fun toString(): String {
        return "Name: " + name + " isFavourite: " + isFavourite
    }
}