package pdm.isel.yawa

import android.app.Application
import android.content.Intent
import com.android.volley.RequestQueue
import com.android.volley.toolbox.Volley

import pdm.isel.yawa.model.connection.ConnectionHandler
import pdm.isel.yawa.model.data.database.SQLDatabase
import pdm.isel.yawa.model.dataBridge.DataBridge
import pdm.isel.yawa.model.provider.IWeatherProvider
import pdm.isel.yawa.model.provider.OpenWeather.OpenWeatherProvider
import java.util.concurrent.CountDownLatch
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.content.IntentFilter


class YAWA : Application() {

    /**
     * Returns the instance of DataBridge being used.
     * @return
     */
    var databridge: DataBridge? = null
        private set
    var connectionHandler : ConnectionHandler? = null

    private lateinit var latch: CountDownLatch
    private var error: AssertionError? = null

    override fun onCreate() {
        super.onCreate()
        connectionHandler = ConnectionHandler(this)
        requestQueue = Volley.newRequestQueue(applicationContext)
        requestQueue.cache.clear()
        // Preparing test harness thread synchronization artifacts
        latch = CountDownLatch(1)
        error = null

        initDataBridge(connectionHandler as ConnectionHandler)
    }

    /**
     * Inits the databridge.
     * @param connectionHandler
     */
    private fun initDataBridge(connectionHandler: ConnectionHandler) {
        val weatherProvider = getWeatherProvider(connectionHandler)
        databridge = DataBridge(weatherProvider, OpenWeatherProvider(baseContext), SQLDatabase(this))
    }

    /**
     * Returns the weather provider to bue used, according to the connectivity state.
     * @param connectionHandler
     * *
     * @return
     */
    private fun getWeatherProvider(connectionHandler: ConnectionHandler): IWeatherProvider {
        return if (connectionHandler.isConnected) OpenWeatherProvider(this) else SQLDatabase(this)
    }

    // returns 3 - we have wifi and data
    // returns 2 - we have wifi only
    // returns 1 - we only have data
    // returns 0 - Dont have a connection
    fun getConnectionState() : Int{

        val activeNetwork = (getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager).activeNetworkInfo
        val isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting

        if(!isConnected){
            return 0
        }

        val isWiFi = activeNetwork.type === ConnectivityManager.TYPE_WIFI
        val isData = activeNetwork.type === ConnectivityManager.TYPE_MOBILE

        if(isWiFi && isData){
            return 3
        }

        if(isWiFi){
            return 2
        }

        return 1
    }


    fun getBatteryState() : Boolean{
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = registerReceiver(null, ifilter)

        val level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1)

        val batteryPct = level / scale.toFloat()

        return (batteryPct * 100) > 25
    }

    @Volatile lateinit var requestQueue: RequestQueue

}