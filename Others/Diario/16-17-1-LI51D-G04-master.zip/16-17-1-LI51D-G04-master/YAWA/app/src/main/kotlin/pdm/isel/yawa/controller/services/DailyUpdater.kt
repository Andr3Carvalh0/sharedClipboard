package pdm.isel.yawa.controller.services

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.preference.PreferenceManager
import android.util.Log
import com.android.volley.RequestQueue
import pdm.isel.yawa.R
import pdm.isel.yawa.YAWA
import pdm.isel.yawa.comms.GetWeatherRequest

class DailyUpdater : Service() {

    override fun onBind(intent: Intent): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.v("Andre", "Daily Updater Service: Started")

        val preferendecs = PreferenceManager.getDefaultSharedPreferences(this)
        if(!preferendecs.getBoolean("PREF_CONNECTION_TYPE", false) && getConnectionState() >= 1  && getBatteryState()) {
            val prefs = this.getSharedPreferences("YAWA", Context.MODE_PRIVATE)
            fetchWeatherInfo(prefs.getString("FavouriteCity", "Lisbon"), (application as YAWA).requestQueue)

            val othersCity = prefs.getStringSet("Cities", null)

            if(othersCity != null){
                for(city :String in othersCity.iterator()){
                    fetchWeatherInfo(city , (application as YAWA).requestQueue)
                }
                Log.v("Andre", "Background: Daily updates...Done!")
            }else{
                Log.v("Andre", "Background: Daily updates...Nothing to do")
            }

        }else{
            Log.v("Andre", "Cant update due to prefs")
        }
        return Service.START_REDELIVER_INTENT
    }

    // returns 3 - we have wifi and data
    // returns 2 - we have wifi only
    // returns 1 - we only have data
    // returns 0 - Dont have a connection
    fun getConnectionState() : Int{
        return (application as YAWA).getConnectionState()
    }

    fun getBatteryState() : Boolean{
        return (application as YAWA).getBatteryState()
    }


    /**
     * Helper method used to fetch the current weather information.
     */
    private fun fetchWeatherInfo(city: String, requestQueue : RequestQueue) {
        requestQueue.add(
                GetWeatherRequest(
                        resources.getString(R.string.weather_daily_main) + city + resources.getString(R.string.weather_daily_end),
                        { weatherDto ->
                            (application as YAWA).databridge!!.database.addCurrent(weatherDto)
                        },
                        { error ->
                            Log.v("Andre", "[DailyUpdater] Error when fetching weather")

                        }

                )
        )
    }


}
