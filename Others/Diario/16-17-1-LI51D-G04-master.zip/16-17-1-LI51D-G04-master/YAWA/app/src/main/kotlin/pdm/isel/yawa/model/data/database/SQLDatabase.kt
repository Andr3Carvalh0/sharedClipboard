package pdm.isel.yawa.model.data.database

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import pdm.isel.yawa.model.data.IDatabase
import pdm.isel.yawa.model.data.database.contentProvider.WeatherContentProviderContract
import pdm.isel.yawa.model.entities.WeatherDto
import pdm.isel.yawa.model.entities.WeatherForecastDto
import pdm.isel.yawa.model.entities.WeatherForecastVO
import pdm.isel.yawa.model.entities.WeatherVO
import java.util.*


/**
 * This class is the one that uses the ContentProvider created for changing
 * the SQLite Database.
 */
class SQLDatabase(ctx: Context) : IDatabase {

    private val contentResolver: ContentResolver

    companion object {
        private val CONTENT = "content://" + WeatherContentProviderContract.AUTHORITY
    }

    init {
        contentResolver = ctx.contentResolver
    }
    
    override fun addCurrent(weather: WeatherDto) {
        if(!getWeatherCursor(weather.name!!).moveToFirst())
            addWeather(weather, null)
        else
            if(!compareWeather(weather, currentWeather(weather.name!!)))
                addWeather(weather, null)
    }

    override fun addForecast(weatherForecast: WeatherForecastDto) {
        if(getForecastWeatherCursor(weatherForecast.city.name).moveToFirst())
            addWeatherForecastDto(compareForecastWeather(weatherForecast, forecastWeather(weatherForecast.city.name)),
                WeatherContract.ForecastWeatherEntry.TABLE_NAME,
                WeatherContract.ForecastWeatherEntry.COLUMN_NAME_CITY)
        else
            addWeatherForecastDto(weatherForecast,
                    WeatherContract.ForecastWeatherEntry.TABLE_NAME,
                    WeatherContract.ForecastWeatherEntry.COLUMN_NAME_CITY)
    }

    override fun currentWeather(city: String): WeatherVO {
        val cursor =  getWeatherCursor(city)
        cursor.moveToFirst()
        return getWeatherVO(cursor)
    }

    override fun forecastWeather(city: String): WeatherForecastVO {
        return getWeatherList(city, getForecastWeatherCursor(city))
    }

    private fun getWeatherCursor(city: String): Cursor{
        val cursor = contentResolver.query(Uri.parse(CONTENT + "/" +
                WeatherContract.CurrentWeatherEntry.TABLE_NAME), arrayOf<String>(),
                WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CITY + " = ?", arrayOf(city), String())
        return cursor
    }

    private fun getForecastWeatherCursor(city: String): Cursor{
        val cursor = contentResolver.query(Uri.parse(CONTENT + "/" +
                WeatherContract.ForecastWeatherEntry.TABLE_NAME), arrayOf<String>(),
                WeatherContract.ForecastWeatherEntry.COLUMN_NAME_CITY + " = ?", arrayOf(city), String())
        return cursor
    }


    /**
     * Creates a WeatherForecastDto based on a Cursor.
     * @param cursor
     * *
     * @return
     */
    private fun getWeatherList(city: String, cursor: Cursor): WeatherForecastVO {
        val list = ArrayList<WeatherVO>()
        while (cursor.moveToNext()) {
            list.add(getWeatherVO(cursor))
        }
        return WeatherForecastVO(city, list)
    }

    /**
     * Crates a WeatherDto based on the first element of a Cursor.
     * @param cursor
     * *
     * @return
     */
    private fun getWeatherVO(cursor: Cursor): WeatherVO {
        val name = cursor.getString(1)
        val temp = cursor.getInt(2)
        val min_temp = cursor.getInt(3)
        val max_temp = cursor.getInt(4)
        val sky = cursor.getString(5)
        val clouds = cursor.getInt(6)
        val image = cursor.getString(7)
        val time = cursor.getString(8)

        return WeatherVO(name, temp, min_temp, max_temp, sky, clouds, image, time)
    }

    /**
     * Inserts a weather city in the table tableName.
     * @param city
     * *
     * @param tableName
     * *
     * @param columnName
     */
    private fun addWeatherCity(city: String, tableName: String, columnName: String) {
        val values = ContentValues()
        values.put(columnName, city)
        contentResolver.insert(Uri.parse(CONTENT + "/" + tableName), values)
    }

    private fun addWeatherForecastDto(forecast: WeatherForecastDto, tableName: String, columnName: String) {
        addWeatherCity(forecast.city.name, tableName, columnName)
        for (w in forecast.list) {
            addWeather(w, forecast.city.name)
        }
    }

    /**
     * Populates a ContentValues with the details of a weather and inserts a weather in
     * the database.
     * @param w
     */
    private fun addWeather(w: WeatherDto, city: String?) {
        val values = ContentValues()

        values.put(WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CITY, city ?: w.name)
        values.put(WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CURR_TEMP, w.main.temp)
        values.put(WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CURR_MIN, w.main.temp_min)
        values.put(WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CURR_MAX, w.main.temp_max)
        values.put(WeatherContract.CurrentWeatherEntry.COLUMN_NAME_SKY, w.weather[0].main)
        values.put(WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CLOUDS, w.clouds.all)
        values.put(WeatherContract.CurrentWeatherEntry.COLUMN_NAME_IMAGE, w.weather[0].icon)
        values.put(WeatherContract.CurrentWeatherEntry.COLUMN_NAME_TIME, w.time)

        contentResolver.insert(Uri.parse(CONTENT + "/" + WeatherContract.CurrentWeatherEntry.TABLE_NAME), values)
    }

    private fun compareWeather(weatherDto: WeatherDto, weatherVo : WeatherVO): Boolean{
        return weatherVo.name == weatherDto.name &&
                weatherVo.clouds == weatherDto.clouds.all &&
                weatherVo.image == weatherDto.weather[0].icon &&
                weatherVo.max_temp.compareTo(weatherDto.main.temp_max) == 0 &&
                weatherVo.min_temp.compareTo(weatherDto.main.temp_min) == 0 &&
                weatherVo.temp.compareTo(weatherDto.main.temp) == 0 &&
                weatherVo.sky == weatherDto.weather[0].main &&
                weatherVo.time == weatherDto.time

    }

    private fun compareForecastWeather(weatherForecast: WeatherForecastDto, weatherForecastVO: WeatherForecastVO): WeatherForecastDto{
        var list = ArrayList<WeatherDto>()
        weatherForecast.list.forEach { it ->
            var w = it
            if(weatherForecastVO.list.find{it -> compareWeather(w, it)} == null)
                list.add(w)
        }
        weatherForecast.list = list
        return weatherForecast
    }
}

