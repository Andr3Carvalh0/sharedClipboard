package pdm.isel.yawa.model.entities

import android.os.Parcel
import android.os.Parcelable
import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import com.fasterxml.jackson.annotation.JsonProperty


/**
 * Class whose instances represent movie information obtained from the remote API.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
data class WeatherDto(
        val weather: List<Weather>,
        val dt: Long,
        val main: Main,
        val wind: Wind,
        val clouds: Clouds,
        @JsonProperty("dt_txt")val time : String?,
        val name: String?

) : Parcelable {

    data class Weather(val id: Int, val main: String, val description: String, val icon: String): Parcelable {

        companion object {
            /** Factory of Weather instances */
            @JvmField @Suppress("unused")
            val CREATOR = object : Parcelable.Creator<Weather> {
                override fun createFromParcel(source: Parcel) = Weather(source)
                override fun newArray(size: Int): Array<Weather?> = arrayOfNulls(size)
            }
        }

        /**
         * Initiates an instance from the given parcel.
         * @param source The parcel from where the data is to be loaded from
         */
        constructor(source: Parcel) : this(
                id = source.readInt(),
                main = source.readString(),
                description = source.readString(),
                icon = source.readString()
        )

        override fun describeContents() = 0

        override fun writeToParcel(dest: Parcel, flags: Int) {
            dest.apply {
                writeInt(id)
                writeString(main)
                writeString(description)
                writeString(icon)
            }
        }
    }

    data class Main(val temp: Double, val pressure: Double, val humidity: Int, val temp_min: Double, val temp_max: Double): Parcelable {

        companion object {
            /** Factory of Main instances */
            @JvmField @Suppress("unused")
            val CREATOR = object : Parcelable.Creator<Main> {
                override fun createFromParcel(source: Parcel) = Main(source)
                override fun newArray(size: Int): Array<Main?> = arrayOfNulls(size)
            }
        }

        /**
         * Initiates an instance from the given parcel.
         * @param source The parcel from where the data is to be loaded from
         */
        constructor(source: Parcel) : this(
                temp = source.readDouble(),
                pressure = source.readDouble(),
                humidity = source.readInt(),
                temp_min = source.readDouble(),
                temp_max = source.readDouble()
        )

        override fun writeToParcel(dest: Parcel, flags: Int) {
            dest.apply {
                writeDouble(temp)
                writeDouble(pressure)
                writeInt(humidity)
                writeDouble(temp_min)
                writeDouble(temp_max)
            }
        }

        override fun describeContents() = 0
    }

    data class Wind(val speed: Double): Parcelable {

        companion object {
            /** Factory of Wind instances */
            @JvmField @Suppress("unused")
            val CREATOR = object : Parcelable.Creator<Wind> {
                override fun createFromParcel(source: Parcel) = Wind(source)
                override fun newArray(size: Int): Array<Wind?> = arrayOfNulls(size)
            }
        }

        /**
         * Initiates an instance from the given parcel.
         * @param source The parcel from where the data is to be loaded from
         */
        constructor(source: Parcel) : this(
                speed = source.readDouble()
        )

        override fun writeToParcel(dest: Parcel, flags: Int) {
            dest.apply {
                writeDouble(speed)
            }
        }

        override fun describeContents() = 0
    }

    data class Clouds(val all: Int): Parcelable {

        companion object {
            /** Factory of Clouds instances */
            @JvmField @Suppress("unused")
            val CREATOR = object : Parcelable.Creator<Clouds> {
                override fun createFromParcel(source: Parcel) = Clouds(source)
                override fun newArray(size: Int): Array<Clouds?> = arrayOfNulls(size)
            }
        }

        /**
         * Initiates an instance from the given parcel.
         * @param source The parcel from where the data is to be loaded from
         */
        constructor(source: Parcel) : this(
                all = source.readInt()
        )

        override fun writeToParcel(dest: Parcel, flags: Int) {
            dest.apply {
                writeInt(all)
            }
        }

        override fun describeContents() = 0
    }

    companion object {
        /** Factory of WeatherDTO instances */
        @JvmField @Suppress("unused")
        val CREATOR = object : Parcelable.Creator<WeatherDto> {
            override fun createFromParcel(source: Parcel) = WeatherDto(source)
            override fun newArray(size: Int): Array<WeatherDto?> = arrayOfNulls(size)
        }
    }

    /**
     * Initiates an instance from the given parcel.
     * @param source The parcel from where the data is to be loaded from
     */
    constructor(source: Parcel) : this(
            weather = mutableListOf<Weather>().apply {  source.readTypedList(this, Weather.CREATOR) },
            dt = source.readLong(),
            main = source.readTypedObject(Main.CREATOR),
            wind = source.readTypedObject(Wind.CREATOR),
            clouds = source.readTypedObject(Clouds.CREATOR),
            time =  source.readString(),
            name = source.readString()
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.apply {
            writeTypedList(weather)
            writeLong(dt)
            writeTypedObject(main, 0)
            writeTypedObject(wind, 0)
            writeTypedObject(clouds, 0)
            writeString(time)
            writeString(name)
        }
    }

    override fun describeContents()= 0
}