package pdm.isel.yawa.model.data


import pdm.isel.yawa.model.entities.WeatherDto
import pdm.isel.yawa.model.entities.WeatherForecastDto
import pdm.isel.yawa.model.provider.IWeatherProvider


/**
 * Interface that defines a database for holding Weather.
 */
interface IDatabase : IWeatherProvider {

    /**
     * Adds current weather to the database.
     * @param weather
     */
    fun addCurrent(weather: WeatherDto)

    /**
     * Add forecast weather to the database.
     * @param weatherForecast
     */
    fun addForecast(weatherForecast: WeatherForecastDto)
}
