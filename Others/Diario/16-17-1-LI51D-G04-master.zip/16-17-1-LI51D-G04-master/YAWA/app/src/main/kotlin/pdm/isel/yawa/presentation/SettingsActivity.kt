package pdm.isel.yawa.presentation

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import pdm.isel.yawa.R

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        supportActionBar?.title = resources.getString(R.string.title_activity_settings)
    }
}
