package pdm.isel.yawa.model.provider

import pdm.isel.yawa.model.entities.WeatherDto
import pdm.isel.yawa.model.entities.WeatherForecastDto
import pdm.isel.yawa.model.entities.WeatherForecastVO
import pdm.isel.yawa.model.entities.WeatherVO
import java.util.*

/**
 * Interface that defines a weather provider with the basic operations.
 */
interface IWeatherProvider {

    /**
     * Returns a WeatherDTO containing current weather.
     * @param city
     * *
     * @return
     */
    fun currentWeather(city: String): WeatherVO

    /**
     * Returns a WeatherForecastDTO containing forecast weather.
     * @param city
     * *
     * @return
     */
    fun forecastWeather(city: String): WeatherForecastVO


    fun transformToWeatherForecastVO(ForecastDto : WeatherForecastDto):WeatherForecastVO{
        val list = ArrayList<WeatherVO>()
        for(weather in ForecastDto.list){
            list.add(WeatherVO(weather.name.orEmpty(), weather.main.temp.toInt(),
                    weather.main.temp_min.toInt(), weather.main.temp_max.toInt(),
                    weather.weather[0].main, weather.clouds.all, weather.weather[0].icon, weather.time))
        }
        return WeatherForecastVO(ForecastDto.city.name, list)
    }

}