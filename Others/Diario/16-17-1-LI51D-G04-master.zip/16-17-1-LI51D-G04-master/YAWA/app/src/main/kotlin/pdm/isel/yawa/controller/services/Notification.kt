package pdm.isel.yawa.controller.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.preference.PreferenceManager
import android.util.Log
import pdm.isel.yawa.controller.broadcastReceivers.Notification.WeatherNotification


class Notification : Service() {

    override fun onBind(intent: Intent): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.v("Andre", "Notification Service: Started")

        val preferendecs = PreferenceManager.getDefaultSharedPreferences(this)
        if(preferendecs.getBoolean("PREF_SEND_NOTIFICATION", false)) {
            WeatherNotification().buildNotification(this)
        }
        return Service.START_REDELIVER_INTENT
    }
}
