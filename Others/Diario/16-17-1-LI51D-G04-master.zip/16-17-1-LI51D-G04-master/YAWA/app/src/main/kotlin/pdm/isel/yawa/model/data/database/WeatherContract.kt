package pdm.isel.yawa.model.data.database

import android.provider.BaseColumns


/**
 * This class contains classes with names columns of the tables used on the database.
 */
class WeatherContract {

    /**
     * Contains the column names of table Current Weather.
     */
    abstract class CurrentWeatherEntry : BaseColumns {
        companion object {
            val ID: String = BaseColumns._ID
            val TABLE_NAME = "CurrentWeather"
            val COLUMN_NAME_CITY = "city"
            val COLUMN_NAME_CURR_TEMP = "feels_like"
            val COLUMN_NAME_CURR_MIN = "temp_min"
            val COLUMN_NAME_CURR_MAX = "temp_max"
            val COLUMN_NAME_SKY = "sky"
            val COLUMN_NAME_CLOUDS = "clouds"
            val COLUMN_NAME_IMAGE = "image"
            val COLUMN_NAME_TIME = "time"
        }
    }

    /**
     * Contains the column names of table Forecast Weather.
     */
    abstract class ForecastWeatherEntry : BaseColumns {
        companion object {
            val ID: String = BaseColumns._ID
            val TABLE_NAME = "ForecastWeather"
            val COLUMN_NAME_CITY = "city"
        }
    }
}