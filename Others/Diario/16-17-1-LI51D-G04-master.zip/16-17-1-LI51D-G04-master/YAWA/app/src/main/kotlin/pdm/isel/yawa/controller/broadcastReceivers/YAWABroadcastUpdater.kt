package pdm.isel.yawa.controller.broadcastReceivers

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.preference.PreferenceManager
import android.util.Log
import pdm.isel.yawa.controller.services.DailyUpdater
import pdm.isel.yawa.controller.services.ForecastUpdater

class YAWABroadcastUpdater : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.v("Andre", "Updater Broadcaster: Started")
        val preferendecs = PreferenceManager.getDefaultSharedPreferences(context)

        val daily = PendingIntent.getService(context, 0, Intent(context, DailyUpdater::class.java), PendingIntent.FLAG_UPDATE_CURRENT)
        val forecast = PendingIntent.getService(context, 0, Intent(context, ForecastUpdater::class.java), PendingIntent.FLAG_UPDATE_CURRENT)

        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setRepeating(AlarmManager.RTC_WAKEUP, 0,
                preferendecs.getString("PREF_SYNC_PERIODICITY", "86400").toLong(), daily)
        am.setRepeating(AlarmManager.RTC_WAKEUP, 0,
                preferendecs.getString("PREF_SYNC_PERIODICITY", "86400").toLong(), forecast)

    }
}
