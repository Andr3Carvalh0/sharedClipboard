package pdm.isel.yawa.model.provider.OpenWeather

import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import com.android.volley.RequestQueue
import com.android.volley.toolbox.Volley
import kotlinx.android.synthetic.main.activity_main.*
import pdm.isel.yawa.R
import pdm.isel.yawa.comms.GetWeatherForecastRequest
import pdm.isel.yawa.comms.GetWeatherRequest
import pdm.isel.yawa.model.entities.*
import pdm.isel.yawa.model.provider.IConnectedWeatherProvider
import pdm.isel.yawa.model.provider.IWeatherProvider
import pdm.isel.yawa.presentation.ForecastActivity
import java.util.*
import java.util.concurrent.CountDownLatch

class OpenWeatherProvider(baseContext: Context) : IConnectedWeatherProvider, IWeatherProvider {

    override fun currentWeather(city: String): WeatherVO {
        val w : WeatherDto = current(city)
        return WeatherVO(w.name.orEmpty(), w.main.temp.toInt(), w.main.temp_min.toInt(), w.main.temp_max.toInt(),
                w.weather[0].main, w.clouds.all, w.weather[0].icon, w.time)
    }

    override fun forecastWeather(city: String): WeatherForecastVO {
        return transformToWeatherForecastVO(forecast(city))
    }

    @Volatile lateinit var requestQueue: RequestQueue
    private lateinit var latch: CountDownLatch
    private var error: AssertionError? = null

    var ctx: Context

    init {
        this.ctx = baseContext
        // Preparing Volley's request queue
        requestQueue = Volley.newRequestQueue(ctx)
        requestQueue.cache.clear()

        // Preparing test harness thread synchronization artifacts
        latch = CountDownLatch(1)
        error = null
    }

    override fun forecast(city: String): WeatherForecastDto {
        var weather =  ArrayList<WeatherForecastDto>()
        GetWeatherForecastRequest(
                ctx.resources.getString(R.string.weather_forecast_main) + city + ctx.resources.getString(R.string.weather_forecast_end),
                { weatherForecastDto ->
                    weather.add(weatherForecastDto)
                },
                { error ->
                    Log.v("Andre", "[OpenWeatherProvider]Error when getting weather forecast")
                }

        )

        return weather[0]
    }

    override fun current(city: String): WeatherDto {
        var weather =  ArrayList<WeatherDto>()

        requestQueue.add(
                GetWeatherRequest(
                        ctx.resources.getString(R.string.weather_daily_main) + city + ctx.resources.getString(R.string.weather_daily_end),
                        { weatherDto ->
                            weather.add(weatherDto)
                        },
                        { error ->
                            Log.v("Andre", "[OpenWeatherProvider]Error when getting weather")
                        }

                )
        )

        return weather[0]
    }
}
