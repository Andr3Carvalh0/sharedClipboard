package pdm.isel.yawa.comms

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import pdm.isel.yawa.R
import pdm.isel.yawa.R.drawable
import pdm.isel.yawa.model.entities.Place
import java.util.*

class FavouritesViewAdapter(mPlaces: ArrayList<Place>) : RecyclerView.Adapter<FavouritesViewAdapter.WrapperHolder>() {
    var places: ArrayList<Place>

    init {
        places = mPlaces
    }

    override fun onBindViewHolder(holder: WrapperHolder?, position: Int) {
        val item = places[position]
        holder!!.bindWeather(item)
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): WrapperHolder {
        val inflatedView = LayoutInflater.from(parent!!.context).inflate(R.layout.favorites_list_entry, parent, false)
        return WrapperHolder(inflatedView, this)
    }

    override fun getItemCount(): Int {
        return places.size
    }

    class WrapperHolder
    (v: View, adapter: FavouritesViewAdapter) : RecyclerView.ViewHolder(v), View.OnClickListener {
        private val mItemImage: ImageView
        private val mDeleteImage: ImageView
        private val mItemDescription: TextView
        private var mPlace: Place? = null
        private val mAdapter: FavouritesViewAdapter

        init {
            mItemImage = v.findViewById(R.id.item_image) as ImageView
            mItemImage.setBackgroundResource(drawable.ic_star_border_black_24dp)
            mDeleteImage = v.findViewById(R.id.delete) as ImageView


            mItemDescription = v.findViewById(R.id.item_description) as TextView
            mAdapter = adapter
            mDeleteImage.setOnClickListener {
                mAdapter.removePlace(mPlace!!.name)
                mAdapter.notifyDataSetChanged()
            }
            v.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            if(mPlace!!.isFavourite){
                mPlace!!.isFavourite = false
            }else {
                mAdapter.removeFavourite()

                mPlace!!.isFavourite = !mPlace!!.isFavourite

            }
            mAdapter.notifyDataSetChanged()
        }

        fun bindWeather(place: Place) {
            mPlace = place
            mItemDescription.text = place.name
            if (place.isFavourite) {
                mItemImage.setBackgroundResource(drawable.ic_star_black_24dp)
            } else {
                mItemImage.setBackgroundResource(drawable.ic_star_border_black_24dp)
            }
        }

    }

    private fun  removePlace(name: String) {
        places
                .filter { it.name == name }
                .forEach { places.remove(it) }

    }

    fun addPlace(place: Place) {
        places.add(place)
    }

    fun getListPlaces(): ArrayList<Place> {
        return places
    }

    fun removeFavourite(){
        for(item : Place in places){
            item.isFavourite = false

        }
    }


}