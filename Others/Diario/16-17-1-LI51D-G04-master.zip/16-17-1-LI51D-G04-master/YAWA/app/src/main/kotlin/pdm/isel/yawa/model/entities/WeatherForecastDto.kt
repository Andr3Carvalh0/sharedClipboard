package pdm.isel.yawa.model.entities

import android.os.Parcel
import android.os.Parcelable
import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import pdm.isel.yawa.model.entities.WeatherDto


/**
 * Class whose instances represent movie information obtained from the remote API.
 */

@JsonIgnoreProperties(ignoreUnknown = true)
data class WeatherForecastDto(
        val city : City,
        var list: List<WeatherDto>
): Parcelable {

        data class City(val name: String): Parcelable {

                companion object {
                        /** Factory of Weather instances */
                        @JvmField @Suppress("unused")
                        val CREATOR = object : Parcelable.Creator<City> {
                                override fun createFromParcel(source: Parcel) = City(source)
                                override fun newArray(size: Int): Array<City?> = arrayOfNulls(size)
                        }
                }

                /**
                 * Initiates an instance from the given parcel.
                 * @param source The parcel from where the data is to be loaded from
                 */
                constructor(source: Parcel) : this(
                        name = source.readString()
                )

                override fun describeContents() = 0

                override fun writeToParcel(dest: Parcel, flags: Int) {
                        dest.apply {
                                writeString(name)
                        }
                }
        }

        companion object {
                /** Factory of Forecast instances */
                @JvmField @Suppress("unused")
                val CREATOR = object : Parcelable.Creator<WeatherForecastDto> {
                        override fun createFromParcel(source: Parcel) = WeatherForecastDto(source)
                        override fun newArray(size: Int): Array<WeatherForecastDto?> = arrayOfNulls(size)
                }
        }

        /**
         * Initiates an instance from the given parcel.
         * @param source The parcel from where the data is to be loaded from
         */
        constructor(source: Parcel) : this(
                city = source.readTypedObject(City.CREATOR),
                list = mutableListOf<WeatherDto>().apply {  source.readTypedList(this, WeatherDto.CREATOR) }
        )

        override fun writeToParcel(dest: Parcel, flags: Int) {
                dest.apply {
                        writeTypedObject(city,0)
                        writeTypedList(list)
                }
        }

        override fun describeContents() = 0

}