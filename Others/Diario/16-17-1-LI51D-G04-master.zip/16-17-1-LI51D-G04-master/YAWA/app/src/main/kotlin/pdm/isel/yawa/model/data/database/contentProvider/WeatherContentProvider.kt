package pdm.isel.yawa.model.data.database.contentProvider

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import pdm.isel.yawa.model.data.database.WeatherContract
import pdm.isel.yawa.model.data.database.WeatherDBHelper


/**
 * This class is the ContentProvider used to access the data supported in
 * the SqLite database.
 */
class WeatherContentProvider : ContentProvider() {

    private var dbHelper: WeatherDBHelper? = null

    override fun onCreate(): Boolean {
        dbHelper = WeatherDBHelper(context)
        return true
    }

    /**
     * Return a Cursor with the result of the query performed.
     *
     * @param uri
     * *
     * @param projection
     * *
     * @param selection
     * *
     * @param selectionArgs
     * *
     * @param sortOrder
     * *
     * @return
     */
    override fun query(uri: Uri, projection: Array<String>, selection: String, selectionArgs: Array<String>, sortOrder: String): Cursor? {
        val db = dbHelper!!.readableDatabase
        var cursor: Cursor? = null

        when (uriMatcher!!.match(uri)) {
            ROOT_MATCH, CURRENT_WEATHER_COLL_MATCH -> {
                cursor = db.query(WeatherContract.CurrentWeatherEntry.TABLE_NAME, projection,
                        selection, selectionArgs,
                        null, null, sortOrder)
                return cursor
            }
            FORECAST_WEATHER_COLL_MATCH -> {
                return getCursorByInnerJoin(db, WeatherContract.ForecastWeatherEntry.TABLE_NAME,
                        WeatherContract.ForecastWeatherEntry.COLUMN_NAME_CITY, selectionArgs[0]);
            }
            CURRENT_WEATHER_ITEM_MATCH -> return getCursorByInnerJoinWhereCurrent(db, uri, projection)
            FORECAST_WEATHER_ITEM_MATCH -> return getCursorByInnerJoinWhereForecast(db, uri, projection)
            else -> return null
        }
    }

    override fun getType(uri: Uri): String? {
        return null
    }

    /**
     * Inserts a weather in the table designated by the parameter uri.
     * @param uri
     * *
     * @param values
     * *
     * @return
     */
    override fun insert(uri: Uri, values: ContentValues): Uri? {
        val db = dbHelper!!.writableDatabase
        val cursor: Cursor? = null

        when (uriMatcher!!.match(uri)) {
            ROOT_MATCH, CURRENT_WEATHER_COLL_MATCH -> {
                db.insert(WeatherContract.CurrentWeatherEntry.TABLE_NAME, null, values)
                return null
            }
            FORECAST_WEATHER_COLL_MATCH -> {
                db.insert(WeatherContract.ForecastWeatherEntry.TABLE_NAME, null, values)
                return null
            }
            else -> return null
        }
    }

    /**
     * Deletes a weather from a table designated by the parameter uri, according to
     * the parameters selection and selectionArgs.
     * @param uri
     * *
     * @param selection
     * *
     * @param selectionArgs
     * *
     * @return
     */
    override fun delete(uri: Uri, selection: String, selectionArgs: Array<String>): Int {
        val db = dbHelper!!.writableDatabase
        val cursor: Cursor? = null
        val id = ContentUris.parseId(uri)

        when (uriMatcher!!.match(uri)) {
            ROOT_MATCH, CURRENT_WEATHER_ITEM_MATCH -> return db.delete(WeatherContract.CurrentWeatherEntry.TABLE_NAME, WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CITY + " = ?", arrayOf(java.lang.Long.toString(id)))
            FORECAST_WEATHER_ITEM_MATCH -> return db.delete(WeatherContract.ForecastWeatherEntry.TABLE_NAME, WeatherContract.ForecastWeatherEntry.COLUMN_NAME_CITY + " = ?", arrayOf(java.lang.Long.toString(id)))
            else -> return 0
        }
    }

    override fun update(uri: Uri, values: ContentValues, selection: String, selectionArgs: Array<String>): Int {
        return 0
    }

    companion object {

        private val AUTHORITY = WeatherContentProviderContract.AUTHORITY

        private var uriMatcher: UriMatcher? = null
        private val ROOT_MATCH = 0
        private val CURRENT_WEATHER_COLL_MATCH = 1
        private val CURRENT_WEATHER_ITEM_MATCH = 2
        private val FORECAST_WEATHER_COLL_MATCH = 3
        private val FORECAST_WEATHER_ITEM_MATCH = 4


        init {
            uriMatcher = UriMatcher(ROOT_MATCH)
            uriMatcher!!.addURI(AUTHORITY, WeatherContract.CurrentWeatherEntry.TABLE_NAME, CURRENT_WEATHER_COLL_MATCH)
            uriMatcher!!.addURI(AUTHORITY, WeatherContract.CurrentWeatherEntry.TABLE_NAME + "/#", CURRENT_WEATHER_ITEM_MATCH)
            uriMatcher!!.addURI(AUTHORITY, WeatherContract.ForecastWeatherEntry.TABLE_NAME, FORECAST_WEATHER_COLL_MATCH)
            uriMatcher!!.addURI(AUTHORITY, WeatherContract.ForecastWeatherEntry.TABLE_NAME + "/#", FORECAST_WEATHER_ITEM_MATCH)
        }

        /**
         * Returns a inner query between the table tableName and the table Movie.
         * @param db
         * *
         * @param tableName
         * *
         * @param tableColumn
         * *
         * @return
         */
        private fun getCursorByInnerJoin(db: SQLiteDatabase, tableName: String, tableColumn: String, city: String): Cursor {
                return db.rawQuery("SELECT W.* FROM " + WeatherContract.CurrentWeatherEntry.TABLE_NAME + " W INNER JOIN " +
                        tableName + " F ON  W.city = F." + tableColumn + " WHERE W.time != \"null\" AND W.city = \"" + city + "\"", null)
        }

        /**
         * Returns the weather with the city passed in the parameters uri.
         * @param db
         * *
         * @param uri
         * *
         * @param projection
         * *
         * @return
         */
        private fun getCursorByInnerJoinWhereCurrent(db: SQLiteDatabase, uri: Uri, projection: Array<String>): Cursor {
            val id = ContentUris.parseId(uri)
            return db.query(WeatherContract.CurrentWeatherEntry.TABLE_NAME, projection, WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CITY + " = ?", arrayOf(java.lang.Long.toString(id)),
                    null, null, null)
        }

        private fun getCursorByInnerJoinWhereForecast(db: SQLiteDatabase, uri: Uri, projection: Array<String>): Cursor {
            val id = ContentUris.parseId(uri)
            return db.query(WeatherContract.ForecastWeatherEntry.TABLE_NAME, projection, WeatherContract.ForecastWeatherEntry.COLUMN_NAME_CITY + " = ?", arrayOf(java.lang.Long.toString(id)),
                    null, null, null)
        }
    }
}

