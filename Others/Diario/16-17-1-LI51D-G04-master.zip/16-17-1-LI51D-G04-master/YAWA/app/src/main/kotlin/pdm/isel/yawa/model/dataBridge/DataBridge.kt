package pdm.isel.yawa.model.dataBridge

import pdm.isel.yawa.model.data.IDatabase
import pdm.isel.yawa.model.entities.WeatherDto
import pdm.isel.yawa.model.entities.WeatherForecastDto
import pdm.isel.yawa.model.entities.WeatherForecastVO
import pdm.isel.yawa.model.entities.WeatherVO
import pdm.isel.yawa.model.provider.IConnectedWeatherProvider
import pdm.isel.yawa.model.provider.IWeatherProvider


/**
 * This class is responsible for handling the requests for movies, according
 * to the providers that are passed in the constructor. It's used as a bridge
 * between the controller and model parts of the app.
 */
class DataBridge(private var weatherProvider: IWeatherProvider?,
                 private val connectedMovieProvider: IConnectedWeatherProvider,
                 val database: IDatabase) {

    /**
     * Returns the daily for city
     * *
     * @return
     */
    fun dailyInfo(city: String): WeatherVO {
        return weatherProvider!!.currentWeather(city)
    }

    /**
     *
     * @return
     */
    fun forecastInfo(city: String): WeatherForecastVO {
        return weatherProvider!!.forecastWeather(city)
    }

    /* IConnectedWeather methods */

    /**
     * Returns daily
     * @return
     */
    fun current(city: String): WeatherDto {
        return connectedMovieProvider.current(city)
    }

    /**
     * Returns forecast
     * @return
     */
    fun forecast(city: String): WeatherForecastDto {
        return connectedMovieProvider.forecast(city)
    }

    /* IDatabase methods */

    /**
     * Returns daily
     * @return
     */
    fun databaseDaily(city: String): WeatherVO {
        return database.currentWeather(city)
    }

    /**
     * Returns forecast
     * @return
     */
    fun databaseForecast(city: String): WeatherForecastVO {
        return database.forecastWeather(city);
    }

}
