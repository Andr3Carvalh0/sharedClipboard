package pdm.isel.yawa.presentation


import android.content.Intent
import android.os.AsyncTask
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_weather.*
import pdm.isel.yawa.R
import pdm.isel.yawa.YAWA
import pdm.isel.yawa.model.entities.WeatherDto
import pdm.isel.yawa.model.entities.WeatherVO

class DailyActivity : AppCompatActivity() {




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather)

        val weather : WeatherVO = intent.getParcelableExtra("weather")
        fillCurrentWeather(weather)
        //AsyncCurrentWeather(savedInstanceState).execute(weather)
    }

    /**
     * Fills the view with the current weather.
     * @param w
     */
    private fun fillCurrentWeather(w: WeatherVO) {
        Picasso.with(applicationContext).load(resources.getString(R.string.weather_condition) + w.image + resources.getString(R.string.weather_condition_extension)).into(weather_codition);
        Current_temp_value.text = "" + w.temp
        Current_Max_Min_value.text = "" + w.max_temp + "ºC" + " / " + w.min_temp + "ºC"
        Sky_value.text = "" + w.sky
        Clouds_value.text = "" + w.clouds + "%"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_home, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId

        //noinspection SimplifiableIfStatement

        if(id == R.id.action_about){
            startActivity(Intent(this, CreditsActivity::class.java))
            return true;
        }
        if(id == R.id.action_settings){
            startActivity(Intent(this, SettingsActivity::class.java))
            return true;
        }


        return super.onOptionsItemSelected(item)
    }

}
