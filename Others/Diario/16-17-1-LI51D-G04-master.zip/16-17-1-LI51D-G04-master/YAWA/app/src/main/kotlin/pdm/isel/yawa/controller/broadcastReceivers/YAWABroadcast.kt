package pdm.isel.yawa.controller.broadcastReceivers

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import pdm.isel.yawa.controller.services.Notification
import java.util.*

class YAWABroadcast : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.v("Andre", "Notification Broadcast: Started")

        val calendar = Calendar.getInstance()

        //For now dont ask the user the hours in which he gets up
        calendar.set(Calendar.HOUR_OF_DAY, 6)
        calendar.set(Calendar.MINUTE, 35)
        calendar.set(Calendar.SECOND, 0)
        val pi = PendingIntent.getService(context, 0,
                Intent(context, Notification::class.java), PendingIntent.FLAG_UPDATE_CURRENT)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.setRepeating(AlarmManager.RTC_WAKEUP, calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY, pi)
    }
}
