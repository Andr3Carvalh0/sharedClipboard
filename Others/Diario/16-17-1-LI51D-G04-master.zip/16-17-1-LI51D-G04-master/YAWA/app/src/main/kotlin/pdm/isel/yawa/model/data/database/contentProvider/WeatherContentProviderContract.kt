package pdm.isel.yawa.model.data.database.contentProvider

/**
 * This class defines the authority of the content provider.
 */
object WeatherContentProviderContract {

    val AUTHORITY = "pdm.isel.yawa"
}