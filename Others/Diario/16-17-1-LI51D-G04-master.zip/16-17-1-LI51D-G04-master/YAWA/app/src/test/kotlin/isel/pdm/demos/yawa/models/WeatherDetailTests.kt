package isel.pdm.demos.yawa.models

import pdm.isel.yawa.models.WeatherDTO
import org.junit.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class WeatherDetailTests {

    @Test
    fun genreInstantiation_producesCorrectObject() {
        val wind = WeatherDTO.Wind(2.16)

        assertEquals(2.16, wind.speed)
    }
/*
    @Test
    fun movieCollectionInstantiation_producesCorrectObject() {

        val ID = 10
        val NAME = "Star Wars"
        val POSTER_PATH = "/thePath"

        val movieCollection = MovieDetail.MovieCollection(ID, NAME, POSTER_PATH, null)

        assertEquals(ID, movieCollection.id)
        assertEquals(NAME, movieCollection.name)
        assertEquals(POSTER_PATH, movieCollection.posterPath)
        assertNull(movieCollection.backdropPath)
    }
*/
    @Test
    fun movieDetailInstantiation_producesCorrectObject() {
        // TODO
    }
}