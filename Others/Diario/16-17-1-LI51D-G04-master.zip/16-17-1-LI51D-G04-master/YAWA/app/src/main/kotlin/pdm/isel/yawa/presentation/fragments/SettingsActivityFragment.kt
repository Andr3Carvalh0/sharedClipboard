package pdm.isel.yawa.presentation.fragments

import android.content.Intent
import android.os.Bundle
import android.preference.Preference
import android.preference.PreferenceFragment


import pdm.isel.yawa.R
import pdm.isel.yawa.presentation.CreditsActivity
import pdm.isel.yawa.presentation.Favourites

/**
 * A placeholder fragment containing a simple view.
 */
class SettingsActivityFragment : PreferenceFragment() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addPreferencesFromResource(R.xml.fragment_settings)


        val button = findPreference("PREF_FAVORITES")

        button.onPreferenceClickListener = Preference.OnPreferenceClickListener {
            startActivity(Intent(activity.baseContext, Favourites::class.java))
            true
        }
    }
}
