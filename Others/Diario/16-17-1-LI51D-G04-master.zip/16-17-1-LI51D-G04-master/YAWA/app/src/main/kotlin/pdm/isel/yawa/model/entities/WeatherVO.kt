package pdm.isel.yawa.model.entities

import android.os.Parcel
import android.os.Parcelable

class WeatherVO(
        val name : String,
        val temp : Int,
        val min_temp : Int,
        val max_temp : Int,
        val sky : String,
        val clouds: Int,
        val image : String,
        val time: String?): Parcelable{

    companion object {
        /** Factory of WeatherVO instances */
        @JvmField @Suppress("unused")
        val CREATOR = object : Parcelable.Creator<WeatherVO> {
            override fun createFromParcel(source: Parcel) = WeatherVO(source)
            override fun newArray(size: Int): Array<WeatherVO?> = arrayOfNulls(size)
        }
    }

    /**
     * Initiates an instance from the given parcel.
     * @param source The parcel from where the data is to be loaded from
     */
    constructor(source: Parcel) : this(
            name = source.readString(),
            temp = source.readInt(),
            min_temp = source.readInt(),
            max_temp = source.readInt(),
            sky = source.readString(),
            clouds = source.readInt(),
            image = source.readString(),
            time = source.readString()
    )

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.apply {
            writeString(name)
            writeInt(temp)
            writeInt(min_temp)
            writeInt(max_temp)
            writeString(sky)
            writeInt(clouds)
            writeString(image)
            writeString(time)
        }
    }

    override fun describeContents()= 0
}