package pdm.isel.yawa.comms

import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso
import pdm.isel.yawa.R
import pdm.isel.yawa.model.entities.WeatherForecastVO
import pdm.isel.yawa.model.entities.WeatherVO
import pdm.isel.yawa.presentation.DailyActivity

import java.util.Calendar

private var weatherForecast: WeatherForecastVO? = null

class RecyclerViewAdapter(weatherForecastDto: WeatherForecastVO) : RecyclerView.Adapter<RecyclerViewAdapter.WrapperHolder>() {

    init{
        weatherForecast = weatherForecastDto
    }

    override fun onBindViewHolder(holder: WrapperHolder?, position: Int) {
        val item = weatherForecast!!.list[position]
        holder!!.bindWeather(item)
    }

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): WrapperHolder {
        val inflatedView = LayoutInflater.from(parent!!.context).inflate(R.layout.forecast_list_entry, parent, false)
        return WrapperHolder(inflatedView)
    }

    override fun getItemCount(): Int {
        return weatherForecast!!.list.size;
    }

    class WrapperHolder
    (v: View) : RecyclerView.ViewHolder(v), View.OnClickListener {
        private val mItemImage: ImageView
        private val mItemDescription: TextView
        private var mWeather: WeatherVO? = null

        init {

            mItemImage = v.findViewById(R.id.item_image) as ImageView
            mItemDescription = v.findViewById(R.id.item_description) as TextView
            v.setOnClickListener(this)
        }

        override fun onClick(v: View) {
            val context = itemView.context
            val showPhotoIntent = Intent(context, DailyActivity::class.java)
            showPhotoIntent.putExtra("weather", mWeather)
            context.startActivity(showPhotoIntent)
        }

        fun bindWeather(weather: WeatherVO) {
            mWeather = weather;
            Picasso.with(mItemImage.context).load(itemView.context.getString(R.string.weather_condition) + weather.image + itemView.context.resources.getString(R.string.weather_condition_extension)).into(mItemImage)
            mItemDescription.text = converter(weather.time)
        }

        private fun converter(time: String?): String? {
            val c = Calendar.getInstance()

            val splitted = time!!.split(" ")
            val date = splitted[0].split("-")
            val hour  = splitted[1].split(":")
            var day = c.get(Calendar.DATE).toString()
            var tmp :String

            if(Integer.parseInt(c.get(Calendar.DATE).toString()) < 10){
                day = "0" + c.get(Calendar.DATE).toString()
            }

            if(day == date[2]){
                tmp = itemView.context.getString(R.string.text_today)
            }else if(Integer.parseInt(day) + 1 == Integer.parseInt(date[2])){
                tmp = itemView.context.getString(R.string.text_tomorrow)
            }else{
                tmp = itemView.context.getString(R.string.text_future)
            }

            return hour[0] + ":" + hour[1] + ", " + tmp
        }
    }
}