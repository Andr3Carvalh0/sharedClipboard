package pdm.isel.yawa.model.provider

import pdm.isel.yawa.model.entities.WeatherDto
import pdm.isel.yawa.model.entities.WeatherForecastDto


/**
 * Interface that defines a weather provider that as connectivity to the internet.
 */

interface IConnectedWeatherProvider {

    /**
     * Returns a WeatherDto containing the weather for a certain city.
     * @param city
     * *
     * @return
     */
    abstract fun current(city: String): WeatherDto

    /**
     * Returns a WeatherForecastDto containing
     * the weathers for a certain city
     * @param city
     * *
     * @return
     */
    abstract fun forecast(city: String): WeatherForecastDto
}