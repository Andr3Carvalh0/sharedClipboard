package pdm.isel.yawa.model.data.memory

import pdm.isel.yawa.model.data.IDatabase
import pdm.isel.yawa.model.entities.*
import java.util.*


/**
 * This class is a mock database used for tests.
 */
class MemoryDatabase : IDatabase {


    companion object {

        private val currentWeather = ArrayList<WeatherDto>()
        private val forecastWeather = ArrayList<WeatherForecastDto>()
        private val favoriteCities = ArrayList<Place>()

    }

    override fun addCurrent(weather: WeatherDto) {
        currentWeather.add(weather)
    }

    override fun addForecast(weatherForecast: WeatherForecastDto) {
        forecastWeather.add(weatherForecast)
    }

    override fun currentWeather(city: String): WeatherVO {
        for (w in currentWeather){
            if (w.name === city){
                return transformToWeatherVO(w)
            }
        }
        return null!!
    }

    override fun forecastWeather(city: String): WeatherForecastVO {
        for(wf in forecastWeather)
            if(wf.city.name === city)
                return transformToWeatherForecastVO(wf)
        return null!!
    }

    fun transformToWeatherVO(WeatherDto : WeatherDto):WeatherVO{
        return WeatherVO(WeatherDto.name!!, WeatherDto.main.temp_min.toInt(), WeatherDto.main.temp_min.toInt(), WeatherDto.main.temp_max.toInt(), WeatherDto.weather[0].main, WeatherDto.clouds.all, WeatherDto.weather[0].icon, WeatherDto.time)
    }
}


