package pdm.isel.yawa.model.connection

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkInfo

class ConnectionHandler(context: Context) {

    private val networkInfo: NetworkInfo?

    init {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        this.networkInfo = connectivityManager.activeNetworkInfo
    }

    /**
     * Returns true if there's connection to the internet.
     * @return
     */
    val isConnected: Boolean
        get() = networkInfo != null && networkInfo.isConnectedOrConnecting

    /**
     * Retruns the connection type that exists, or NO_CONNCETION_TYPE if there's no connection.
     * @return
     */
    val connectionType: Int
        get() = if (isConnected) networkInfo!!.type else NO_CONNECTION_TYPE

    companion object {
        private val NO_CONNECTION_TYPE = -1
    }
}
