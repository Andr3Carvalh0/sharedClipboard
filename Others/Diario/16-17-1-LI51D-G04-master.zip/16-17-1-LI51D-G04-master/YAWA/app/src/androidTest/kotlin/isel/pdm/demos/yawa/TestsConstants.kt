package isel.pdm.demos.yawa

const val APP_PACKAGE: String = "isel.pdm.demos.yawa"
const val INTERNET_PERMISSION: String = "android.permission.INTERNET"
const val WEATHER_URL: String = "http://api.openweathermap.org/data/2.5/weather?q=Lisbon,pt&units=metric&appid=6f2164619dbc15ce02193c065df0e540"
const val WEATHER_FORECAST: String = "http://api.openweathermap.org/data/2.5/forecast/weather?q=Lisbon,pt&units=metric&appid=6f2164619dbc15ce02193c065df0e540"
