package pdm.isel.yawa.controller.broadcastReceivers.Notification

import android.app.NotificationManager
import android.content.Context
import android.support.v7.app.NotificationCompat
import pdm.isel.yawa.R
import android.content.Context.NOTIFICATION_SERVICE
import android.content.res.Resources
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.android.volley.RequestQueue
import kotlinx.android.synthetic.main.activity_main.*
import pdm.isel.yawa.YAWA
import pdm.isel.yawa.comms.GetWeatherRequest
import pdm.isel.yawa.model.entities.WeatherVO

class WeatherNotification{
    fun buildNotification(ctx: Context) {
        val prefs = ctx.getSharedPreferences("YAWA", Context.MODE_PRIVATE)
        val favCity = prefs.getString("FavouriteCity", "Lisbon")

        val weather = (ctx as YAWA).databridge!!.databaseDaily(favCity)
        var notificationBody = ""

        if(weather.min_temp < 8 || weather.max_temp < 15){
            notificationBody = ctx.getString(R.string.weather_notification_status_cold)
        }else if(weather.sky == "Clouds" || weather.sky == "Rain"){
            notificationBody = ctx.getString(R.string.weather_notification_status_rain)
        }else{
            notificationBody = ctx.getString(R.string.weather_notification_status_sunny)
        }

        val mBuilder = NotificationCompat.Builder(ctx)
                .setSmallIcon(R.drawable.settings_icon)
                .setContentTitle(ctx.getString(R.string.weather_notification_title))
                .setContentText(notificationBody)

        // Sets an ID for the notification
        val mNotificationId = 1
        // Gets an instance of the NotificationManager service
        val mNotifyMgr = ctx.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        // Builds the notification and issues it.
        mNotifyMgr.notify(mNotificationId, mBuilder.build())

    }
}