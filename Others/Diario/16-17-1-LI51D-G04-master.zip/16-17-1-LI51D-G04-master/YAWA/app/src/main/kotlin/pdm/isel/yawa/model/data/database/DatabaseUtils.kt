package pdm.isel.yawa.model.data.database

/**
 * This class holds the SqLite statements used for creating, and deleting,
 * all the tables used in the database.
 */
object DatabaseUtils {

    private val TEXT_TYPE = " TEXT"
    private val INTEGER_TYPE = " INTEGER"
    private val REAL_TYPE = " REAL"
    private val COMMA_SEP = ","

    /**
     * Statement used for creating the Current Weather table.
     */
    val SQL_CREATE_CURRENT_WEATHER = "CREATE TABLE " +
            WeatherContract.CurrentWeatherEntry.TABLE_NAME + " (" +
            WeatherContract.CurrentWeatherEntry.ID + INTEGER_TYPE + " PRIMARY KEY," +
            WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CITY + TEXT_TYPE + COMMA_SEP +
            WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CURR_TEMP + TEXT_TYPE + COMMA_SEP +
            WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CURR_MIN + TEXT_TYPE + COMMA_SEP +
            WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CURR_MAX + TEXT_TYPE + COMMA_SEP +
            WeatherContract.CurrentWeatherEntry.COLUMN_NAME_SKY + TEXT_TYPE + COMMA_SEP +
            WeatherContract.CurrentWeatherEntry.COLUMN_NAME_CLOUDS + TEXT_TYPE + COMMA_SEP +
            WeatherContract.CurrentWeatherEntry.COLUMN_NAME_IMAGE + TEXT_TYPE + COMMA_SEP +
            WeatherContract.CurrentWeatherEntry.COLUMN_NAME_TIME +  " )"


    /**
     * Statement used for creating the Forecast Weather table.
     */
    val SQL_CREATE_FORECAST_WEATHER = "CREATE TABLE " +
            WeatherContract.ForecastWeatherEntry.TABLE_NAME + " (" +
            WeatherContract.ForecastWeatherEntry.ID + INTEGER_TYPE + " PRIMARY KEY, " +
            WeatherContract.ForecastWeatherEntry.COLUMN_NAME_CITY + TEXT_TYPE + " )"



    /**
     * Statement used for deleting the Current Weather table.
     */
    val SQL_DELETE_CURRENT_WEATHER = "DROP TABLE IF EXISTS " + WeatherContract.CurrentWeatherEntry.TABLE_NAME

    /**
     * Statement used for deleting the Forecast Weather table.
     */
    val SQL_DELETE_FORECAST_WEATHER = "DROP TABLE IF EXISTS " + WeatherContract.ForecastWeatherEntry.TABLE_NAME

}